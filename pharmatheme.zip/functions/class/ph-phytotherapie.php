<?php

class PharmaLoop_phytotherapie extends PharmaLoop_aromatherapie {

}
